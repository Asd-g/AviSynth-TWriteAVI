/*
**   TWriteAvi for AviSynth 2.5.x
**   
**   Copyright (C) 2005 Kevin Stone
**
**   This program is free software; you can redistribute it and/or modify
**   it under the terms of the GNU General Public License as published by
**   the Free Software Foundation; either version 2 of the License, or
**   (at your option) any later version.
**
**   This program is distributed in the hope that it will be useful,
**   but WITHOUT ANY WARRANTY; without even the implied warranty of
**   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**   GNU General Public License for more details.
**
**   You should have received a copy of the GNU General Public License
**   along with this program; if not, write to the Free Software
**   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <windows.h>
#include <vfw.h>
#include <stdio.h>
#include <shlwapi.h>
#include "avisynth.h"
#include "OutputAvi.h"

enum FourCCs {
	FCC_NULL = 0x00000000,
	FCC_DIB  = 0x20424944
};

#define NO_RECOMPRESS (cvar.fccHandler == FCC_NULL)
HINSTANCE g_hInst; // vdub stuff

class TWriteAvi : public GenericVideoFilter
{
private:
	BITMAPINFOHEADER bih;
	COMPVARS cvar;
	unsigned char *lpBuffer;
	const char *fname;
	char fullname[MAX_PATH];
	bool overwrite, showAll;
	OutputFormat* out;
	AVISTREAMINFO SRCStreamInfo;
	int KFCount, BFCount, lastFrame;

public:
	PVideoFrame __stdcall TWriteAvi::GetFrame(int n, IScriptEnvironment *env);
	TWriteAvi::TWriteAvi(PClip _child, const char* _fname, bool _overwrite, bool _showAll,
		IScriptEnvironment *env);
	TWriteAvi::~TWriteAvi();
};

TWriteAvi::TWriteAvi(PClip _child, const char* _fname, bool _overwrite, bool _showAll, 
		IScriptEnvironment *env) : GenericVideoFilter(_child), fname(_fname), 
		overwrite(_overwrite), showAll(_showAll)
{
	if (!vi.IsRGB() && !vi.IsYUY2() && !vi.IsYV12())
		env->ThrowError("TWriteAvi:  unsupported colorspace!");
	if (!vi.HasVideo())
		env->ThrowError("TWriteAvi:  input clip does not contain video!");
	if (!(*fname))
		env->ThrowError("TWriteAvi:  no output filename specified!");
	child->SetCacheHints(CACHE_NOTHING, 0);
	KFCount = BFCount = 0;
	lastFrame = -97832;
	lpBuffer = NULL;
	out = NULL;
	memset(&bih, 0, sizeof(BITMAPINFOHEADER));
	memset(&cvar, 0, sizeof(COMPVARS));
	memset(&SRCStreamInfo, 0, sizeof(AVISTREAMINFO));
	// check destination path/name
	void *htemp = _fullpath(fullname, fname, MAX_PATH);
	if (htemp == NULL) env->ThrowError("TWriteAvi:  error getting full file path!");
	if (PathFileExists(fullname)) 
	{
		if (overwrite) 
		{
			HANDLE hFile = CreateFile(fullname, GENERIC_READ | GENERIC_WRITE,
				FILE_SHARE_READ, NULL, CREATE_ALWAYS, 0, NULL);
			if (hFile != INVALID_HANDLE_VALUE) CloseHandle(hFile);
			else env->ThrowError("TWriteAvi:  output file already exists and unable to overwrite!");
		}
		else env->ThrowError("TWriteAvi:  output file already exists!");
	}
	// fill BITMAPINFOHEADER bih info
	bih.biSize = sizeof(BITMAPINFOHEADER); 
	bih.biWidth = vi.width;
	bih.biHeight = vi.height;
	bih.biPlanes = 1;
	bih.biBitCount = vi.BitsPerPixel();
	if (vi.IsYUY2()) bih.biCompression = '2YUY';
	else if (vi.IsYV12()) bih.biCompression = '21VY';
	else bih.biCompression = BI_RGB;
	bih.biSizeImage = vi.BMPSize();
	// select compressor and fill COMPVARS cvar info
	cvar.cbSize = sizeof(COMPVARS);
	if (showAll)
	{
		if(!ICCompressorChoose(NULL, ICMF_CHOOSE_ALLCOMPRESSORS | ICMF_CHOOSE_DATARATE | 
			ICMF_CHOOSE_KEYFRAME | ICMF_CHOOSE_PREVIEW, &bih, NULL, &cvar, (LPSTR)fname)) 
			env->ThrowError("TWriteAvi:  ICCompressorChoose failed!");
	}
	else
	{
		if(!ICCompressorChoose(NULL, ICMF_CHOOSE_DATARATE | ICMF_CHOOSE_KEYFRAME | ICMF_CHOOSE_PREVIEW, 
			&bih, NULL, &cvar, (LPSTR)fname)) env->ThrowError("TWriteAvi:  ICCompressorChoose failed!");
	}
	if (cvar.fccHandler == FCC_DIB) 
		env->ThrowError("TWriteAvi:  valid compressor not chosen (FCC_DIB, Full Frames)!");
	// fill AVISTREAMINFO SRCStreamInfo info
	SRCStreamInfo.fccType = streamtypeVIDEO;
	SRCStreamInfo.dwQuality = DWORD(-1);
	if (vi.IsRGB()) SRCStreamInfo.fccHandler = ' BID';
	else if (vi.IsYUY2()) SRCStreamInfo.fccHandler = '2YUY';
	else SRCStreamInfo.fccHandler = '21VY'; 
	SRCStreamInfo.dwScale = vi.fps_denominator;
	SRCStreamInfo.dwRate = vi.fps_numerator;
	SRCStreamInfo.dwLength = vi.num_frames;
	SRCStreamInfo.rcFrame.right = vi.width;
	SRCStreamInfo.rcFrame.bottom = vi.height;
	SRCStreamInfo.dwSampleSize = vi.BMPSize();
	SRCStreamInfo.dwSuggestedBufferSize = vi.BMPSize();
	strcpy(SRCStreamInfo.szName,"Avisynth Video");
	// allocate temporary storage buffer - lpBuffer
	lpBuffer = (unsigned char *)malloc(vi.BMPSize());
	if (lpBuffer == NULL) env->ThrowError("TWriteAvi:  malloc failure!");
	// set up compressor and output object
	if (NO_RECOMPRESS) out = new OutputAvi(fullname, &SRCStreamInfo, &bih);
	else
	{
		int formatSize = ICCompressGetFormatSize(cvar.hic, (void*)&bih);
		BITMAPINFOHEADER *bih2 = (BITMAPINFOHEADER*)malloc(formatSize);
		memset(bih2, 0, formatSize);
		ICCompressGetFormat(cvar.hic, &bih, bih2);
		if (bih2->biSize == 0) bih2->biSize = formatSize;
		out = new OutputAvi(fullname, SRCStreamInfo.dwLength, SRCStreamInfo.dwRate,
					SRCStreamInfo.dwScale, cvar.fccHandler, cvar.lQ, bih2);
		free(bih2);
		ICCOMPRESSFRAMES iccf;
		memset(&iccf, 0, sizeof(ICCOMPRESSFRAMES));
		iccf.dwRate = SRCStreamInfo.dwRate;
		iccf.dwScale = SRCStreamInfo.dwScale;
		iccf.lQuality = cvar.lQ;
		iccf.lDataRate = cvar.lDataRate<<10;
		iccf.lKeyRate = cvar.lKey;
		ICSendMessage(cvar.hic, ICM_COMPRESS_FRAMES_INFO, (DWORD)&iccf, sizeof(ICCOMPRESSFRAMES));
		if (!ICSeqCompressFrameStart(&cvar, (LPBITMAPINFO)&bih))
			env->ThrowError("TWriteAvi:  ICSeqCompressFrameStart failed!");
	}
}

TWriteAvi::~TWriteAvi()
{
	if (!NO_RECOMPRESS) 
	{
		if (BFCount > 0 && lastFrame >= 0) // b-frame delay handling
		{
			BOOL KF_Flag;
			LONG DSTDataSize;
			void *DSTData;
			for (int i=0; i<BFCount; ++i)
			{
				DSTData = ICSeqCompressFrame(&cvar, 0, lpBuffer, &KF_Flag, &DSTDataSize);
				if (!DSTData) { i = BFCount+1; continue; }
				if (KF_Flag) KFCount++;
				if (DSTDataSize == 1 && (*(byte*)DSTData == 0x7F)) BFCount++;
				else out->writeData(DSTData, DSTDataSize, KF_Flag);
			}
		}
		ICSeqCompressFrameEnd(&cvar);
	}
	ICCompressorFree(&cvar);
	if (lpBuffer != NULL) free(lpBuffer);
	if (out != NULL) delete out;
}

PVideoFrame __stdcall TWriteAvi::GetFrame(int n, IScriptEnvironment *env)
{
	lastFrame = n;
	PVideoFrame frame = child->GetFrame(n, env);
	int pitch = frame->GetPitch();
	int width = frame->GetRowSize();
	int out_pitch = (width+3)&-4;
	env->BitBlt(lpBuffer, out_pitch, frame->GetReadPtr(), pitch, width, frame->GetHeight());
	env->BitBlt(lpBuffer+(out_pitch*frame->GetHeight()), out_pitch/2, frame->GetReadPtr(PLANAR_V), 
		frame->GetPitch(PLANAR_V), frame->GetRowSize(PLANAR_V), frame->GetHeight(PLANAR_V));
	env->BitBlt(lpBuffer+(out_pitch*frame->GetHeight()+frame->GetHeight(PLANAR_U)*out_pitch/2), 
		out_pitch/2, frame->GetReadPtr(PLANAR_U), frame->GetPitch(PLANAR_U), frame->GetRowSize(PLANAR_V), 
		frame->GetHeight(PLANAR_U));
	if (NO_RECOMPRESS) 
	{
		out->writeData(lpBuffer, vi.BMPSize(), true);
		KFCount++;
	}
	else
	{
		BOOL KF_Flag;
		LONG DSTDataSize;
		void *DSTData = ICSeqCompressFrame(&cvar, 0, lpBuffer, &KF_Flag, &DSTDataSize);
		if (!DSTData) env->ThrowError("TWriteAvi:  ICSeqCompressFrame failed!");
		if (KF_Flag) KFCount++;
		if (DSTDataSize == 1 && (*(byte*)DSTData == 0x7F)) BFCount++;
		else out->writeData(DSTData, DSTDataSize, KF_Flag);
	}
	return frame;
}

AVSValue __cdecl Create_TWriteAvi(AVSValue args, void* user_data, IScriptEnvironment* env)
{
    return new TWriteAvi(args[0].AsClip(),args[1].AsString(""),args[2].AsBool(false),
		args[3].AsBool(false),env);
}

extern "C" __declspec(dllexport) const char* __stdcall AvisynthPluginInit2(IScriptEnvironment* env) 
{
    env->AddFunction("TWriteAvi", "c[fname]s[overwrite]b[showAll]b", Create_TWriteAvi, 0);
	return 0;
}